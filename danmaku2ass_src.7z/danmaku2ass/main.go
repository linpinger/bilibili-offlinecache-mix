package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"

	"github.com/Hami-Lemon/converter"
)

var (
	Gwidth    int = 1280
	Gheight   int = 720
	Gfontsize int = 16

	GxmlFilePath string = ""
	GassFilePath string = "sub.ass"
)

func main() {
	flag.IntVar(&Gwidth, "w", Gwidth, "视频分辨率的宽")
	flag.IntVar(&Gheight, "h", Gheight, "视频分辨率的高")
	flag.IntVar(&Gfontsize, "s", Gfontsize, "字体大小")
	flag.StringVar(&GxmlFilePath, "i", GxmlFilePath, "弹幕xml文件路径（B站）")
	flag.StringVar(&GassFilePath, "o", GassFilePath, "保存ass文件路径")
	flag.Parse()

	// 魔改成从管道读取xml内容，写入sub.ass，例如 cat danmaku.xml | bcc

	f, err := os.Open(filepath.Dir(os.Args[0]) + string(os.PathSeparator) + "setting.json")
	var setting Setting
	if err != nil {
		if os.IsNotExist(err) {
			setting = DefaultSetting
		} else {
			fmt.Fprintln(os.Stderr, err)
		}
	} else {
		setting = ReadSetting(f)
	}
	setting.Width = Gwidth
	setting.Height = Gheight
	setting.Fontsize = Gfontsize

	assConfig := setting.GetAssConfig()
	chain := converter.NewFilterChain()
	keywordFilter, typeFilter := setting.GetFilter()
	chain.AddFilter(keywordFilter).AddFilter(typeFilter)

	//如果在go程中加载xml，当文件过多时会出现过高的内存占用
	var pool * converter.BulletChatPool
	sSrc := "stdin"
	if "" != GxmlFilePath {
		src, _ := os.Open(GxmlFilePath)
		if src == nil {
			fmt.Fprintf(os.Stderr, "# 弹幕文件打开错误: %s\n", GxmlFilePath)
			return
		}
		sSrc = GxmlFilePath
		pool = converter.LoadPool(src, chain)
	} else {
		pool = converter.LoadPool(os.Stdin, chain)
	}

	dst, err := os.Create(GassFilePath)
	defer dst.Close()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return
	}
	if err := pool.Convert(dst, assConfig); err == nil {
		fmt.Fprintf(os.Stderr, "# ok: %s ==> %s\n", sSrc, GassFilePath)
	} else {
		fmt.Fprintln(os.Stderr, "# failed:", sSrc, "==>", GassFilePath, ":", err)
	}

}
