package main

import (
	"math/rand"
	"net/http"
	"time"
	"image"
	"image/color"
	"image/draw"
	"image/png"
)

// 随机favicon
func randomColor() color.RGBA {
	rand.Seed(time.Now().UnixNano())
	return color.RGBA{
		R: uint8(rand.Intn(256)),
		G: uint8(rand.Intn(256)),
		B: uint8(rand.Intn(256)),
		A: 255,
		}
}

func drawCircle(img draw.Image, x, y, r int, c color.Color) {
	for i := -r; i <= r; i++ {
		for j := -r; j <= r; j++ {
			if i*i+j*j <= r*r {
				img.Set(x+i, y+j, c)
			}
		}
	}
}

func faviconHandler(w http.ResponseWriter, r *http.Request) {
	size := 32
	img := image.NewRGBA(image.Rect(0, 0, size, size))
	c := randomColor()
	drawCircle(img, size/2, size/2, size/2-1, c)

	w.Header().Set("Content-Type", "image/x-icon")
	err := png.Encode(w, img)
	if err != nil {
		http.Error(w, "Failed to generate favicon", http.StatusInternalServerError)
		return
	}
}

