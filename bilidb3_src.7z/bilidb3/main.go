package main

// 删除当前目录下所有空文件夹: find . -type d -empty -delete

// http://127.0.0.1:29129/bilicache.db3

import (
	_ "embed"
	"flag"
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/tidwall/gjson"
)

const DefAndroidHtmlPath = "/sdcard/FoxBook/html/bili_index.html"
const DefAndroidStaticDir = "/sdcard/FoxBook/html/js/"

//go:embed bili_index.html
var HTMLIndex string

var (
	staticDir = "D:/etc/js/"
	HtmlPath = "D:/tmp/tmp_prj/bili/golang/bilidb3/bili_index.html"

	DBName	= "bilicache.db3"
	SelectSQL = "select * from bilicache order by tsc desc"

	bHTTPD	= false

	bUpdateDB = false

	bListDB  = false
	bMakeMKV = false
	bCopyDir = false
	bMoveDir = false
	bDelDir  = false

	bRenewDir  = false

	bTransAll2MKV = false

	iCID = ""
	iIDX = -1
)

func resetVar() { // 多次调用函数，在用完后要重置全局变量
	iCID = ""
	iIDX = -1
}

func main() {
	flag.BoolVar(&bTransAll2MKV, "a", bTransAll2MKV, "动作: 直接(不读取db)将所有目录转mkv，放到upid目录下")

	flag.StringVar(&iCID, "c", iCID, "参数: 视频CID")
	flag.IntVar(&iIDX, "n", iIDX, "参数: 视频编号")

	flag.BoolVar(&bHTTPD, "b", bHTTPD, "动作: 启用httpd")

	flag.BoolVar(&bListDB, "l", bListDB, "动作: 列出数据库中的信息")
	flag.BoolVar(&bMakeMKV, "m", bMakeMKV, "动作: 合成mkv，结合参数n或c")
	flag.BoolVar(&bCopyDir, "cp", bCopyDir, "动作: 复制指定视频到当前目录，结合参数n或c")
	flag.BoolVar(&bMoveDir, "mv", bMoveDir, "动作: 移动指定视频到当前目录，结合参数n或c")
	flag.BoolVar(&bDelDir, "d", bDelDir, "动作: 删除指定目录，结合参数n或c")

	flag.BoolVar(&bRenewDir, "r", bRenewDir, "动作: 整理数据库中所有目录的路径: upid/avid/c_cid/，其中avid/c_cid/是安卓app中的组织形式")

	flag.BoolVar(&bUpdateDB, "u", bUpdateDB, "动作: 更新本目录下的数据库")
	flag.Parse()

	// start
	if bTransAll2MKV {
		doTransAll2MKV(".")
	}
	if bRenewDir {
		doRenewDir()
	}
	if bListDB {
		doListDB()
	}
	if bUpdateDB {
		updateDB(".")
	}
	if bMakeMKV {
		doMerge2MKV()
	}
	if bCopyDir {
		doCopy()
	}
	if bMoveDir {
		fmt.Println("- TODO: bMoveDir: idx:", iIDX, "cid:", iCID)
	}
	if bDelDir {
		doDeleteDir()
	}
	if bHTTPD {
		srv := &http.Server{Addr: ":29129" }
		fmt.Fprintln(os.Stderr, "# Listen: 29129 @ .")

		if "android" == runtime.GOOS {
			staticDir = DefAndroidStaticDir
			HtmlPath  = DefAndroidHtmlPath
		}

		http.HandleFunc("/gogogo", NewHandlerHTMLFunc) // 处理网页请求
		http.HandleFunc("/favicon.ico", faviconHandler)
		http.HandleFunc("/" + DBName, htmlHandler)
		http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir(staticDir))))
		http.Handle("/", NewHandlerStaticFile(".", "")) // 静态文件处理
		if err := srv.ListenAndServe(); err != nil {
			fmt.Fprintln(os.Stderr, "# Error: ListenAndServe: ", err)
		}
	}
}

func NewHandlerHTMLFunc(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(os.Stderr, "-", r.RemoteAddr, "->", r.Method, r.RequestURI)
	if "GET" == r.Method {
		switch r.FormValue("a") {
		case "getlist":
			w.Header().Add("Content-Type", "application/json")
			w.WriteHeader(200)

			result, err := QuerySQLiteJson("select * from bilicache order by tsc desc")
			if err != nil {
				fmt.Fprintf(os.Stderr, "查询失败: %v", err)
			}

			fmt.Fprintf(w, "%s", result)
		case "dodeldir":
			iCID = r.FormValue("cid")
			doDeleteDir()

			w.Header().Add("Content-Type", "text/plain")
			w.WriteHeader(200)
			fmt.Fprintf(w, "%s", "ok:" + iCID)
		case "domergemkv":
			iCID = r.FormValue("cid")
			doMerge2MKV()

			w.Header().Add("Content-Type", "text/plain")
			w.WriteHeader(200)
			fmt.Fprintf(w, "%s", "ok:" + iCID)
			resetVar()
		default:
			fmt.Fprint(w, HTMLIndex)
		}
	}
	if "POST" == r.Method {
	}
}

func htmlHandler(w http.ResponseWriter, r *http.Request) {
	if _, err := os.Stat(HtmlPath); err == nil || os.IsExist(err) {
		fmt.Println("请求:", r.RemoteAddr, "->", r.RequestURI)
		t, _ := template.ParseFiles(HtmlPath)
		t.Execute(w, nil)
	} else {
		fmt.Println("请求embed:", r.RemoteAddr, "->", r.RequestURI)
		fmt.Fprint(w, HTMLIndex)
	}
}



func doDeleteDir() {
	var row map[string]string
	if iIDX > -1 {
		result, _ := QuerySQLiteOBJ("select path, cnname, cid from bilicache order by tsc desc")
		if iIDX < len(result) {
			row = result[iIDX]
		} else {
			return
		}
	}
	if iCID != "" {
		result, _ := QuerySQLiteOBJ("select path, cnname, cid from bilicache where cid = '" + iCID + "';")
		if 1 == len(result) {
			row = result[0]
		} else {
			return
		}
	}

	if nil == row {
		return
	}

	os.RemoveAll(row["path"])
	if err := os.RemoveAll(row["path"]) ; err != nil {
		fmt.Fprintf(os.Stderr, "# 错误: RemoveAll: %s : %s : %v\n", row["path"], row["cnname"], err)
	} else {
		ExecuteSQL("CREATE TABLE IF NOT EXISTS bilideleted AS SELECT * FROM bilicache WHERE 1 = 0; INSERT INTO bilideleted SELECT * FROM bilicache WHERE cid = '" + row["cid"] + "'; DELETE FROM bilicache WHERE cid = '" + row["cid"] + "';")
		fmt.Fprintf(os.Stderr, "- RemoveAll: %s : %s\n", row["path"], row["cnname"])
	}

}

func doRenewDir() {
	result, _ := QuerySQLiteOBJ(SelectSQL)
	newPath := "upid/avid/c_cid/"
	for _, row := range result {
		newPath = row["upid"] + "/" + row["avid"] + "/c_" + row["cid"]
		os.MkdirAll(row["upid"] + "/" + row["avid"], 0770)
		if errM := os.Rename(row["path"], newPath) ; errM != nil {
			fmt.Fprintf(os.Stderr, "# 错误: Rename: %s -> %s\n", row["path"], newPath)
		} else {
			fmt.Fprintf(os.Stderr, "- %s -> %s\n", row["path"], newPath)
		}
	}
}

func doMerge2MKV() {
	var row map[string]string
	if iIDX > -1 {
		result, _ := QuerySQLiteOBJ("select * from bilicache order by tsc desc;")
		if iIDX < len(result) {
			row = result[iIDX]
		} else {
			return
		}
	}
	if iCID != "" {
		result, _ := QuerySQLiteOBJ("select * from bilicache where cid = '" + iCID + "';")
		if 1 == len(result) {
			row = result[0]
		} else {
			return
		}
	}

	if nil == row {
		return
	}

	cnName := row["cnname"]
	fmt.Println("- 合成:", cnName)

	mkvPath := dir2mkv(row) // 单cid目录转mkv
	if errM := os.Rename(mkvPath, cnName) ; errM != nil {
		fmt.Println("# 错误移动文件: bili.mkv ->", cnName)
	}

}

func doCopy() {
	var row map[string]string
	if iIDX > -1 {
		result, _ := QuerySQLiteOBJ("select * from bilicache order by tsc desc;")
		if iIDX < len(result) {
			row = result[iIDX]
		} else {
			return
		}
	}
	if iCID != "" {
		result, _ := QuerySQLiteOBJ("select * from bilicache where cid = '" + iCID + "';")
		if 1 == len(result) {
			row = result[0]
		} else {
			return
		}
	}

	if nil == row {
		return
	}

	errc := CopyDirectory(row["path"], "cp_bili/" + row["path"])
	if errc != nil {
		fmt.Printf("# 复制失败: %v\n", errc)
	} else {
		fmt.Printf("- 复制完成: %s -> %s\n", row["path"], "cp_bili/" + row["path"])
		fmt.Printf("- %s : %s\n", row["cid"], row["cnname"])
	}
}

func doListDB() {
	data, err := QuerySQLiteOBJ(SelectSQL)
	if err != nil {
		fmt.Println("# 查询出错:", err)
		return
	}

	for i, row := range data {
		fmt.Printf("%d : %s : %s\n", i, row["cid"], row["cnname"])
	}

}


// 处理 entry.json 和 index.json 得到各字段
func getEntryMap(entryJsonPath, startDir string) map[string]string {
	oMap := make(map[string]string)

	nowDir := filepath.Dir(entryJsonPath)
	// 获取相对路径
	relPath, err := filepath.Rel(startDir, nowDir)
	if err != nil {
		fmt.Fprintf(os.Stderr, "# 无法获取相对路径 %s: %v", entryJsonPath, err)
		return nil
	}
	oMap["path"] = relPath

	// 读取 JSON 文件
	bJson, err := ioutil.ReadFile(entryJsonPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "# 无法读取文件 %s: %v", entryJsonPath, err)
		return nil
	}
	sJson := string(bJson)

	// 解析 entry.json
	oMap["tsc"] = gjson.Get(sJson, `time_create_stamp`).String()
	oMap["bvid"] = gjson.Get(sJson, `bvid`).String()
	oMap["upname"] = gjson.Get(sJson, `owner_name`).String()
	oMap["upid"] = gjson.Get(sJson, `owner_id`).String()
	oMap["vdir"] = gjson.Get(sJson, `video_quality`).String()
	oMap["title"] = gjson.Get(sJson, `page_data.download_subtitle`).String()
	oMap["avid"] = gjson.Get(sJson, `avid`).String()
	oMap["cid"] = gjson.Get(sJson, `page_data.cid`).String()
	oMap["page"] = gjson.Get(sJson, `page_data.page`).String()
	oMap["part"] = gjson.Get(sJson, `page_data.part`).String()

	oMap["titlep"] = gjson.Get(sJson, `title`).String()
	oMap["vlen"] = gjson.Get(sJson, `total_bytes`).String()
	oMap["vsec"] = gjson.Get(sJson, `total_time_milli`).String()
	oMap["vq"] = gjson.Get(sJson, `quality_pithy_description`).String()

	// 解析 index.json
	iJsonPath := nowDir + "/" + oMap["vdir"] + "/" + "index.json"
	iJson, err := ioutil.ReadFile(iJsonPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "# 无法读取文件 %s: %v", iJsonPath, err)
		return nil
	}
	oMap["vw"] = gjson.Get(string(iJson), `video|0|width`).String()
	oMap["vh"] = gjson.Get(string(iJson), `video|0|height`).String()

	oMap["cnname"] = getCNName(oMap["tsc"], oMap["bvid"], oMap["upname"], oMap["part"], oMap["title"], oMap["vw"], oMap["vh"])

	return oMap
}

func getCNName(ts10, bvid, upname, part, title, vw, vh string) string {
	sTime, err := formatTimestamp(ts10) // 1694305688947 ==> 2023-09-10_082808
	if err != nil {
		fmt.Println("# Error: formatTimestamp():", err)
		sTime = ts10
	}
	if len(title) < 2 {
		title = part
	}
	title = getLastNChars(title)
	// ${sTime}_${upname}_${title}_{wh}_${bvid}.mkv
	return pureName(sTime + "_" + upname + "_" + title + "_" + vw + "x" + vh + "_" + bvid + ".mkv")
}

func formatTimestamp(tsc string) (string, error) {
    // 将字符串转换为 int64 类型的时间戳
    timestamp, err := strconv.ParseInt(tsc, 10, 64)
    if err != nil {
        return "", err
    }
    // 将 13 位时间戳转换为秒
    timestamp = timestamp / 1000
    // 将时间戳转换为 time.Time 类型
    t := time.Unix(timestamp, 0)

    // 设置时区为东八区
    loc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t = t.In(loc)

    // 按照指定格式进行格式化
    return t.Format("2006-01-02_150405"), nil
}

func getLastNChars(iName string) string { // 取末尾30个中英字符
	length := len([]rune(iName))
	if length <= 30 {
		return iName
	}
	return string([]rune(iName)[length-30:])
}

func pureName(iName string) string { // 替换文件名中不允许的字符
	invalidChars := regexp.MustCompile(`[\\/:*?,+" '<>|]`)
	iName = invalidChars.ReplaceAllString(iName, ".")
	iName = strings.ReplaceAll(iName, "...", ".")
	iName = strings.ReplaceAll(iName, "..", ".")
	iName = strings.ReplaceAll(iName, "--", "-")
	iName = strings.ReplaceAll(iName, "__", "_")
	return iName
}

// path, tsc, bvid, upname, page, part, title, titlep, vlen, vsec, vq, vdir, avid, cid, vw, vh, upid, cnname

