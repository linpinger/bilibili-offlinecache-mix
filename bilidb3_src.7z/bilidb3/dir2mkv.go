package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
)

func doTransAll2MKV(rootDir string) {
	// 遍历目录
	if err := filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// 只处理 entry.json 文件
		if !info.IsDir() && strings.HasSuffix(info.Name(), "entry.json") {
			eMap := getEntryMap(path, rootDir)

			os.MkdirAll(eMap["upid"] + "_" + eMap["upname"], 0770)
			newPath := eMap["upid"] + "_" + eMap["upname"] + "/" + eMap["cnname"] // 放到 ./upid/xxx.mkv，也可直接放到 ./

			fmt.Printf("- %s : %s\n", eMap["path"], newPath)

			// 转换
			mkvPath := dir2mkv(eMap) // 单cid目录转mkv

			if errM := os.Rename(mkvPath, newPath) ; errM != nil {
				fmt.Println("# 文件重命名错误: ", mkvPath, "==>", newPath)
			}

		}

		return nil
	}) ; err != nil {
		fmt.Fprintln(os.Stderr, err)
	}
}

// 单cid目录转mkv
func dir2mkv(row map[string]string) string {
	// danmaku.xml -> ass
	vDir := row["path"] + "/" + row["vdir"] + "/"
	// danmaku2ass -i ../danmaku.xml -w $vw -h $vh -s $fontsize
	cmdDM := exec.Command("danmaku2ass", "-i", "../danmaku.xml", "-w", row["vw"], "-h", row["vh"], "-s", convertAndCompare(row["vw"]))
	cmdDM.Dir = vDir
	cmdDM.Output()

	// ffmpeg -loglevel quiet -i $aurl -i $vurl -i sub.ass -c copy -c:s ass ${enname} ;
	cmdFF := exec.Command("ffmpeg", "-i", "audio.m4s", "-i", "video.m4s", "-i", "sub.ass", "-c", "copy", "-c:s", "ass", "bili.mkv")
	cmdFF.Dir = vDir
	cmdFF.Output()
	return vDir + "bili.mkv"
}

//	if errM := os.Rename(dir2mkv(row), cnName) ; errM != nil {
//		fmt.Println("# 错误移动文件: bili.mkv ->", cnName)
//	}


// 比较 视频宽 以确定弹幕字体大小
func convertAndCompare(vw string) string {
	num, err := strconv.Atoi(vw)
	if err != nil {
		return "40"
	}
	if num <= 1280 {
		return "30"
	}
	return "50"
}

