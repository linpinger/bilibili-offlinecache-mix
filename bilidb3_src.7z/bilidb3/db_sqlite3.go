package main

import (
	"database/sql"
	"encoding/json"

	"fmt"
	"os"
	"path/filepath"
	"strings"

	_ "github.com/mattn/go-sqlite3"
)

func updateDB(rootDir string) {
	if _, err := os.Stat(rootDir); os.IsNotExist(err) {
		fmt.Fprintf(os.Stderr, "# 目录 %s 不存在", rootDir)
	}

	// 打开或创建 SQLite3 数据库
	db, err := sql.Open("sqlite3", DBName)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
	}
	defer db.Close()

	// xxx/{avid}/c_{page_data.cid}/entry.json
	// 创建表
	_, err = db.Exec(`
		CREATE TABLE IF NOT EXISTS bilicache (
			path TEXT,

			tsc BIGINT,
			bvid TEXT,
			upname TEXT,
			page TEXT,
			part TEXT,
			title TEXT,

			titlep TEXT,
			vlen TEXT,
			vsec TEXT,
			vq TEXT,

			vdir TEXT,
			avid TEXT,
			cid TEXT,

			vw TEXT,
			vh TEXT,
			upid TEXT,
			cnname TEXT
		)
	`)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
	}

	// 准备插入语句
	stmt, err := db.Prepare("INSERT OR REPLACE INTO bilicache(path, tsc, bvid, upname, page, part, title, titlep, vlen, vsec, vq, vdir, avid, cid, vw, vh, upid, cnname) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
	}
	defer stmt.Close()

	// 遍历目录
	err = filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// 只处理 entry.json 文件
		if !info.IsDir() && strings.HasSuffix(info.Name(), "entry.json") {
			eMap := getEntryMap(path, rootDir)

			// 插入数据库
			_, err = stmt.Exec( eMap["path"], eMap["tsc"], eMap["bvid"], eMap["upname"], eMap["page"], eMap["part"], eMap["title"], eMap["titlep"], eMap["vlen"], eMap["vsec"], eMap["vq"], eMap["vdir"], eMap["avid"], eMap["cid"], eMap["vw"], eMap["vh"], eMap["upid"], eMap["cnname"] )
			if err != nil {
				fmt.Fprintf(os.Stderr, "# 无法插入数据库记录 %s: %v", path, err)
				return nil
			}

			fmt.Printf("- %s : %s\n", eMap["path"], eMap["cnname"])
		}

		return nil
	})

	if err != nil {
		fmt.Fprintln(os.Stderr, err)
	}

	fmt.Println("# 所有 entry.json 文件信息已成功导入数据库")
}


func QuerySQLiteOBJ(iSQL string) ([]map[string]string, error) {
	// 打开数据库连接
	db, err := sql.Open("sqlite3", DBName)
	if err != nil {
		return nil, fmt.Errorf("打开数据库失败: %v", err)
	}
	defer db.Close() // 延迟关闭连接

	// 执行查询
	rows, err := db.Query(iSQL)
	if err != nil {
		return nil, fmt.Errorf("执行查询失败: %v", err)
	}
	defer rows.Close() // 延迟关闭结果集

	// 获取列名
	columns, err := rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("获取列名失败: %v", err)
	}

	// 初始化结果切片
	var result []map[string]string

	// 创建值切片（用于存储每行数据）
	values := make([]interface{}, len(columns))
	valuePointers := make([]interface{}, len(columns))
	for i := range values {
		valuePointers[i] = &values[i]
	}

	// 遍历结果集
	for rows.Next() {
		// 扫描行数据到值指针切片
		if err := rows.Scan(valuePointers...); err != nil {
			return nil, fmt.Errorf("扫描行数据失败: %v", err)
		}

		// 构建单行数据映射
		rowData := make(map[string]string)
		for i, col := range columns {
			val := values[i]
			// 处理 SQLite 空值（NULL）
			if val == nil {
				rowData[col] = "NULL"
			} else {
				rowData[col] = fmt.Sprintf("%v", val)
			}
		}
		result = append(result, rowData)
	}

	// 检查遍历错误
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("遍历结果集失败: %v", err)
	}

	return result, nil
}


// QuerySQLite 查询 SQLite 数据库并返回 JSON 结果
func QuerySQLiteJson(iSQL string) (string, error) {
	result, err := QuerySQLiteOBJ(iSQL)

	// 序列化为 JSON
	jsonData, err := json.Marshal(result)
	if err != nil {
		return "", fmt.Errorf("JSON 序列化失败: %v", err)
	}

	return string(jsonData), nil
}


// ExecuteSQL 执行传入的 SQL 语句操作 SQLite3 数据库
func ExecuteSQL(iSQL string) error {
    db, err := sql.Open("sqlite3", DBName)
    if err != nil {
        return fmt.Errorf("# 无法打开数据库: %w", err)
    }
    defer db.Close()

    // 执行 SQL 语句
    _, err = db.Exec(iSQL)
    if err != nil {
        return fmt.Errorf("# 执行 SQL 语句时出错: %w", err)
    }
    return nil
}

